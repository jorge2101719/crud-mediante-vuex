import Vue from 'vue'
import App from './App.vue'
import router from './router'
import vuetify from './plugins/vuetify'
import Element from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCHswdltLA45fSwSz7uG7MGwo-uXAv_4yo",
  authDomain: "proyecto2-65a05.firebaseapp.com",
  projectId: "proyecto2-65a05",
  storageBucket: "proyecto2-65a05.appspot.com",
  messagingSenderId: "754274303666",
  appId: "1:754274303666:web:f726f1ebf66f818f0ed3ab"
};

// Initialize Firebase
//const app = initializeApp(firebaseConfig);
initializeApp(firebaseConfig);

Vue.use(Element)
Vue.config.productionTip = false

new Vue({
  router,
  vuetify,
  render: h => h(App)
}).$mount('#app')
