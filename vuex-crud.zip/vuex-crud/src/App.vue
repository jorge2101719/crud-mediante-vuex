<template>
  <v-app>
    <v-app-bar
      app
      color="primary"
      dark
    >
      <div class="d-flex align-center">
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="https://cdn.vuetifyjs.com/images/logos/vuetify-logo-dark.png"
          transition="scale-transition"
          width="40"
        />

        <v-img
          alt="Vuetify Name"
          class="shrink mt-1 hidden-sm-and-down"
          contain
          min-width="100"
          src="https://cdn.vuetifyjs.com/images/logos/vuetify-name-dark.png"
          width="100"
        />
      </div>

      <v-spacer></v-spacer>

      <v-btn
        href="https://github.com/vuetifyjs/vuetify/releases/latest"
        target="_blank"
        text
      >
        <span class="mr-2">Latest Release</span>
        <v-icon>mdi-open-in-new</v-icon>
      </v-btn>
    </v-app-bar>

    <v-main>
      <router-view/>
    </v-main>

    <!--<input v-model="documentID"/>-->
    <!--<input placeholder="Ingrese el nombre de la base de datos" />-->

    <!--<button @click="getDocument">traer documento</button>-->
    <button @click="getDocument">Traer documentos</button>

    <ul>
      <li v-for="(usuario, i) in usuarios" :key="i">
        {{ usuario.data.name }} <button @click="deleteUser(usuario.id)">Borrar</button>
      </li>
    </ul>
  </v-app>

  <!--<div id="app">
    <input v-model="documentID"/>

    <button @click="getDocument">traer documento</button>
  </div>-->
</template>

<script>
// Importación de un documento
//import { getFirestore, doc, getDoc } from 'firebase/firestore';
// Importación de varios documentos
import { getFirestore, doc, collection, getDocs, deleteDoc } from 'firebase/firestore';

export default {
  name: 'App',

  data() {
    return {
      //documentID: '',
      usuarios: []
    }
  },
// Método para traer un documento. Forma estática
  methods: {
    async getDocument() {
      //const { usuarios } = [];
      const db = getFirestore();
      //const { documentID } = this;// equivalente a: const documentID = this.documenID
      //const docRef = doc( db, 'usuarios', documentID );
      //const document = await getDoc( docRef );
      //const usuario = {
      //  id: document.id,
      //  data: document.data()
      //};
      //console.log(document);
      //console.log(usuario);
      const collectionRef = collection(db, 'usuarios');
      const documents = await getDocs(collectionRef);
      const users = [];
      documents.forEach((doc) => {
        users.push({ id: doc.id, data: doc.data() })
      });
      this.usuarios = users;
      //console.log(documents);
    },

    async deleteUser(userID) {
      const db = getFirestore();
      await deleteDoc(doc(db, 'usuarios', userID));
      alert('Usuario eliminado con éxito');
    }
  }
};
</script>

<style scoped>
button {
  background-color: greenyellow;
}
input {
  background-color: aquamarine;
}
</style>